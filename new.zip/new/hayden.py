# -*- coding: utf-8 -*-
from linepy import *
from thrift.protocol import TCompactProtocol
from thrift.transport import THttpClient
from akad.ttypes import IdentityProvider, LoginResultType, LoginRequest, LoginType
from akad.ttypes import Message, Location
from line.ttypes import *
from line import SecondaryQrCodeLoginService, SecondaryQrCodeLoginPermitNoticeService
import axolotl_curve25519 as Curve25519
import axolotl_curve25519 as curve
from datetime import datetime, timedelta
from bs4 import BeautifulSoup
from multiprocessing import Pool, Process
from humanfriendly import format_timespan, parse_timespan, format_size, format_number, format_length
from threading import Thread
from urllib.parse import urlparse, urlsplit, urljoin, unwrap, quote, unquote, _splittype, _splithost, _splitport, _splituser, _splitpasswd,  _splitattr, _splitquery, _splitvalue, _splittag, _to_bytes, unquote_to_bytes, urlunparse
from urllib.error import URLError, HTTPError, ContentTooShortError
from urllib.response import addinfourl, addclosehook
from urllib.request import urlopen, urlretrieve, urlcleanup, request_host
from gtts import gTTS
#from googletrans import Translator
#from google_trans_new import google_translator
from deep_translator import GoogleTranslator
from subprocess import Popen, PIPE
#from PIL import Image, ImageDraw, ImageFont, ImageFilter, ImageOps
from os.path import getmtime
#from tiktok_downloader import snaptik,ssstik,tikmate,mdown
#from TikTokApi import TikTokApi 
import pyqrcode
import png
import pyshorteners, pyimgflip, time, youtube_dl, threading, string, requests, urllib3, random, sys, json, codecs, re, os, requests, ast, pytz, atexit, traceback, base64, pafy, livejson, timeago, math, humanize, argparse
_session = requests.session()

client = LINE("")
clientMid = client.profile.mid
clientPoll = OEPoll(client)
botStart = time.time()
bot_save=[__file__]
bot_save_sc=[(f,getmtime(f)) for f in bot_save]
settingsOpen = codecs.open("jsons/hayden/settings.json","r","utf-8")
settings = json.load(settingsOpen)

def restartBot():
    print ("[ INFO ] BOT RESTART")
    backupData()
    time.sleep(1)
    python = sys.executable
    os.execl(python, python, *sys.argv)
def saveSc():
    for f,mtime in bot_save_sc:
      if getmtime(f) != mtime:
          time.sleep(3)
          restartBot()
def backupData():
    try:
        backup = settings
        f = codecs.open('jsons/hayden/settings.json','w','utf-8')
        json.dump(backup, f, sort_keys=True, indent=4, ensure_ascii=False)
        return True
    except Exception as error:
        logError(error)
        return False
def createSecondaryQrCodeLoginService(host, headers):
    transport = THttpClient.THttpClient(host)
    transport.setCustomHeaders(headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    myclient = SecondaryQrCodeLoginService.Client(protocol)
    return myclient
def createSecondaryQrCodeLoginPermitNoticeService(host, headers):
    transport = THttpClient.THttpClient(host)
    transport.setCustomHeaders(headers)
    protocol = TCompactProtocol.TCompactProtocol(transport)
    myclient = SecondaryQrCodeLoginPermitNoticeService.Client(protocol)
    return myclient
def genE2EESecret():
    private_key = curve.generatePrivateKey(os.urandom(32))
    public_key = curve.generatePublicKey(private_key)
    secret = urllib.parse.quote(base64.b64encode(public_key).decode())
    version = 1
    return f"?secret={secret}&e2eeVersion={version}"
def linkqr(to,her):
    url =pyqrcode.create(her, error='L', version=8, mode='binary')
    url.png("big-number.png",scale=8) 
    client.sendImage(to,"big-number.png")
def login(to,her):
    certnya = her
    host = 'https://gxx.line.naver.jp'
    qrEndpoint = '/acct/lgn/sq/v1'
    verifierEndpoint = '/acct/lp/lgn/sq/v1'
    url = host+qrEndpoint
    headers1 = {
    'User-Agent': 'Line/10.15.2',
    'X-Line-Application': 'DESKTOPWIN\t5.21.3\tWindows\t10;SECONDARY',
    'x-lal': 'en_id'
    }
    cl = createSecondaryQrCodeLoginService(url, headers1)
    session = cl.createSession(CreateQrSessionRequest())
    session_id = session.authSessionId
    qrcode = cl.createQrCode(CreateQrCodeRequest(session_id))
    private_key = Curve25519.generatePrivateKey(os.urandom(32))
    public_key = Curve25519.generatePublicKey(private_key)
    nonce = os.urandom(16)
    secret = base64.b64encode(public_key).decode()
    e2ee = '?secret={secret}&e2eeVersion=1'.format(secret=quote(secret))
    qrcode1 = qrcode
    qrcode2 = qrcode1.callbackUrl
    linkqr(to,qrcode2)
    url = host+verifierEndpoint
    headers2 = {
   'User-Agent': 'Line/10.15.2',
   'X-Line-Application': 'DESKTOPWIN\t5.21.3\tWindows\t10;SECONDARY',
   'X-Line-Access': session_id,
   'x-lal': 'en_id'
    }
    cl_verif = createSecondaryQrCodeLoginPermitNoticeService(url, headers2)
    qrverified = cl_verif.checkQrCodeVerified(CheckQrCodeVerifiedRequest(session_id))
    certificate = certnya
    try:
      certverified = cl.verifyCertificate(VerifyCertificateRequest(session.authSessionId, certificate))
    except SecondaryQrCodeException as error:
      pincode = cl.createPinCode(CreatePinCodeRequest(session.authSessionId))
      ret = "Your pincode {}".format(pincode.pinCode)
      client.sendMessage(to, ret)
      pincodeverified = cl_verif.checkPinCodeVerified(CheckPinCodeVerifiedRequest(session.authSessionId))
    except Exception:
      traceback.print_exc()
    qrcodelogin = cl.qrCodeLogin(QrCodeLoginRequest(session.authSessionId, 'ZidanBotsV2', True))
    mycert = qrcodelogin.certificate
    mytoken = qrcodelogin.accessToken
    client.sendMessage(to,"Login user sukses \n\n{}".format(mytoken))

def logError(text):
    client.log("[ ERROR ] {}".format(str(text)))
    tz = pytz.timezone("Asia/Jakarta")
    timeNow = datetime.now(tz=tz)
    timeHours = datetime.strftime(timeNow,"(%H:%M)")
    day = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday","Friday", "Saturday"]
    hari = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jumat", "Sabtu"]
    bulan = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"]
    inihari = datetime.now(tz=tz)
    hr = inihari.strftime('%A')
    bln = inihari.strftime('%m')
    for i in range(len(day)):
        if hr == day[i]: hasil = hari[i]
    for k in range(0, len(bulan)):
        if bln == str(k): bln = bulan[k-1]
    time = "{}, {} - {} - {} | {}".format(str(hasil), str(inihari.strftime('%d')), str(bln), str(inihari.strftime('%Y')), str(inihari.strftime('%H:%M:%S')))
    with open("logError.txt","a") as error:
        error.write("\n[ {} ] {}".format(str(time), text))        
def command(text):
    pesan = text.lower()
    if settings["setKey"] == True:
        if pesan.startswith(settings["keyCommand"]):
            cmd = pesan.replace(settings["keyCommand"],"")
        else:
            cmd = "Undefined command"
    else:
        cmd = text.lower()
    return cmd
def removeCmd(cmd, text):
	key = settings["keyCommand"]
	if settings["setKey"] == False: key = ''
	rmv = len(key + cmd) + 1
	return text[rmv:]
def clientBot(op):
    try:
        if op.type == 25:
            try:
            except Exception as error:
                logError(error)
                traceback.print_tb(error.__traceback__)
    except Exception as error:
        logError(error)
        traceback.print_tb(error.__traceback__)        
