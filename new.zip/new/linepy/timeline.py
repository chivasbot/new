# -*- coding: utf-8 -*-
from datetime import datetime
from .channel import Channel

import json, time, base64, hashlib

def loggedIn(func):
    def checkLogin(*args, **kwargs):
        if args[0].isLogin:
            return func(*args, **kwargs)
        else:
            args[0].callback.other('You want to call the function, you must login to LINE')
    return checkLogin
    
class Timeline(Channel):

    def __init__(self):
        if not self.channelId:
            self.channelId = self.server.CHANNEL_ID['LINE_TIMELINE']
        Channel.__init__(self, self.channel, self.channelId, False)
        self.tl = self.getChannelResult()
        self.__loginTimeline()
        
    def __loginTimeline(self):
        self.server.setTimelineHeadersWithDict({
            'Content-Type': 'application/json',
            'User-Agent': self.server.USER_AGENT,
            'X-Line-Mid': self.profile.mid,
            'X-Line-Carrier': self.server.CARRIER,
            'X-Line-Application': self.server.APP_NAME,
            'X-Line-ChannelToken': self.tl.channelAccessToken
        })
        self.profileDetail = self.getProfileDetail()
        
    """Setting Group"""

    @loggedIn
    def updateGroupPicture(self, groupId, path):
        files = {'file': open(path, 'rb')}
        data = {'params': self.genOBSParams({'oid': groupId,'type': 'image'})}
        r = self.server.postContent(self.server.LINE_OBS_DOMAIN + '/talk/g/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Update group picture failure.')
        return True
    @loggedIn
    def updateProfileCoverById2(self, homeId, objid, vObjid=None, storyShare=False):
        data = {
            "homeId": homeId,
            "coverObjectId": objid,
            "storyShare": storyShare,
            "meta":{} # heh
        }
        if vObjid:
            data['videoCoverObjectId'] = vObjid
        hr = self.server.additionalHeaders(self.server.timelineHeaders, {
            'x-lhm': "POST",
            'Content-type': "application/json",
        })
        r = self.server.postContent('https://ga2.line.naver.jp/hm/api/v1/home/cover.json', headers=hr, data=json.dumps(data))
        return r.json()
    @loggedIn
    def updateGroupCover(self, groupId, path):
        objid = self.uploadObjHome(path, type="image", returnAs='objId')
        home = self.updateProfileCoverById2(groupId,objid)
        return True
    @loggedIn
    def updateGroupCoverVideo(self, groupId, path):
        home = self.getProfileCoverDetail(groupId)
        cv = "https://obs.line-apps.com/r/myhome/c/"+home['result']['coverObsInfo']['objectId']
        datacv = self.downloadFileURL(cv)
        objid = self.uploadObjHome(datacv, type="image",returnAs='objId')
        home1 = self.updateProfileCoverById2(groupId,objid)
        self.uploadObjHome(path, type="video", objId=objid)
        home2 = self.updateProfileCoverById2(groupId,objid,objid)
        return  True
    @loggedIn
    def updateGroupCoverPictureAndVideo(self, groupId, path,pathv):
        objid = self.uploadObjHome(path, type="image", returnAs='objId')
        home1=self.updateProfileCoverById2(groupId,objid)
        self.uploadObjHome(pathv, type="video", objId=objid)
        home2 = self.updateProfileCoverById2(groupId,objid,objid)
        return True

    """Setting Profile"""

    @loggedIn
    def updateProfilePicture(self, path, type='p'):
        files = {'file': open(path, 'rb')}
        params = {'oid': self.profile.mid,'type': 'image'}
        if type == 'vp':
            params.update({'ver': '2.0', 'cat': 'vp.mp4'})
        data = {'params': self.genOBSParams(params)}
        r = self.server.postContent(self.server.LINE_OBS_DOMAIN + '/talk/p/upload.nhn', data=data, files=files)
        if r.status_code != 201:
            raise Exception('Update profile picture failure.')
        return True

    @loggedIn
    def updateVideoAndPictureProfile(self, path_p, path, returnAs='bool'):
        if returnAs not in ['bool']:
            raise Exception('Invalid returnAs value')
        files = {'file': open(path, 'rb')}
        data = {'params': self.genOBSParams({'oid': self.profile.mid,'ver': '2.0','type': 'video','cat': 'vp.mp4'})}
        r_vp = self.server.postContent(self.server.LINE_OBS_DOMAIN + '/talk/vp/upload.nhn', data=data, files=files)
        if r_vp.status_code != 201:
            raise Exception('Update profile video picture failure.')
        self.updateProfilePicture(path_p, 'vp')
        if returnAs == 'bool':
            return True
      
    @loggedIn
    def updateProfileCoverById(self, objId):
        params = {'coverImageId': objId}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/home/updateCover.json', params)
        r = self.server.getContent(url, headers=self.server.timelineHeaders)
        return r.json()
      
    @loggedIn
    def updateProfileCoverById1(self, objid, vObjid=None, storyShare=False):
        data = {
            "homeId": self.profile.mid,
            "coverObjectId": objid,
            "storyShare": storyShare,
            "meta":{} # heh
        }
        if vObjid:
            data['videoCoverObjectId'] = vObjid
        hr = self.server.additionalHeaders(self.server.timelineHeaders, {
            'x-lhm': "POST",
            'Content-type': "application/json",
        })
        r = self.server.postContent('https://ga2.line.naver.jp/hm/api/v1/home/cover.json', headers=hr, data=json.dumps(data))
        return r.json()
        
    @loggedIn
    def updateProfileCover(self, path):
        objid = self.uploadObjHome(path, type="image", returnAs='objId')
        home = self.updateProfileCoverById(objid)
        return True
      
    @loggedIn
    def updateProfileCoverPicture(self, path):
        home = self.getProfileCoverDetail()
        if "videoCoverObsInfo" in home['result']:
          cv = "https://obs.line-apps.com/r/myhome/vc/"+home['result']['videoCoverObsInfo']['objectId']
          datacv = self.downloadFileURL(cv)
          objid = self.uploadObjHome(path, type="image",returnAs='objId')
          home1 = self.updateProfileCoverById1(objid)
          self.uploadObjHome(datacv, type="video", objId=objid)
          home2 = self.updateProfileCoverById1(objid,objid)
          return True
        else:
          self.updateProfileCover(path)
            
    @loggedIn
    def updateProfileCoverVideo(self, path):
        home = self.getProfileCoverDetail()
        cv = "https://obs.line-apps.com/r/myhome/c/"+home['result']['coverObsInfo']['objectId']
        datacv = self.downloadFileURL(cv)
        objid = self.uploadObjHome(datacv, type="image",returnAs='objId')
        home1 = self.updateProfileCoverById1(objid)
        self.uploadObjHome(path, type="video", objId=objid)
        home2 = self.updateProfileCoverById1(objid,objid)
        return  True
      
    @loggedIn
    def updateProfileCoverPictureAndVideo(self, path,pathv):
        objid = self.uploadObjHome(path, type="image", returnAs='objId')
        home1=self.updateProfileCoverById1(objid)
        self.uploadObjHome(pathv, type="video", objId=objid)
        home2 = self.updateProfileCoverById1(objid,objid)
        return True

    """Timeline"""

    @loggedIn
    def getFeed(self, postLimit=10, commentLimit=1, likeLimit=1, order='TIME'):
        params = {'postLimit': postLimit, 'commentLimit': commentLimit, 'likeLimit': likeLimit, 'order': order}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/feed/list.json', params)
        r = self.server.getContent(url, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def getHomeProfile(self, mid=None, postLimit=10, commentLimit=1, likeLimit=1):
        if mid is None:
            mid = self.profile.mid
        params = {'homeId': mid, 'postLimit': postLimit, 'commentLimit': commentLimit, 'likeLimit': likeLimit, 'sourceType': 'LINE_PROFILE_COVER'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/list.json', params)
        r = self.server.getContent(url, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def getProfileDetail(self, mid=None):
        if mid is None:
            mid = self.profile.mid
        params = {'userMid': mid}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v1/userpopup/getDetail.json', params)
        r = self.server.getContent(url, headers=self.server.timelineHeaders)
        return r.json()
      
    @loggedIn
    def getProfileCoverDetail(self, mid=None):
        if mid is None:
            mid = self.profile.mid
        params = {
            'homeId': mid
        }        
        hr = self.server.additionalHeaders(self.server.timelineHeaders, {
            'x-lhm': "GET",
        })
        url = self.server.urlEncode('https://ga2.line.naver.jp/hm', '/api/v1/home/cover.json', params)
        r = self.server.postContent(url, headers=hr, data='')
        return r.json()

    @loggedIn
    def getSocialProfileDetail(self, mid, withSocialHomeInfo=True, postLimit=None, likeLimit=6, commentLimit=10, storyVersion='v7', timelineVersion='v57', postId=None, updatedTime=None):
        params = {
            'homeId': mid,
            'withSocialHomeInfo': withSocialHomeInfo,
            'postLimit': postLimit,
            'likeLimit': likeLimit,
            'commentLimit': commentLimit,
            'storyVersion': storyVersion,
            'timelineVersion': timelineVersion
        }
        if postId is not None:
            # post offset
            params['postId'] = postId
            params['updatedTime'] = updatedTime
        hr = self.server.additionalHeaders(self.server.timelineHeaders, {
            'x-lhm': "GET"
        })
        url = self.server.urlEncode(self.server.LINE_HOST_DOMAIN, '/hm/api/v1/home/socialprofile/post.json', params)
        r = self.server.postContent(url, headers=hr, data='')
        return r.json()
      
    @loggedIn
    def getProfileCoverId(self, mid=None):
        if mid is None:
            mid = self.profile.mid
        home = self.getProfileDetail(mid)
        return home['result']['objectId']

    @loggedIn
    def getProfileCoverURL(self, mid=None):
        if mid is None:
            mid = self.profile.mid
        home = self.getProfileCoverDetail(mid)
        if "videoCoverObsInfo" in home['result']:
          cv = home['result']['videoCoverObsInfo']['objectId']
          c = home['result']['coverObsInfo']['objectId']
          res="Link video : https://obs.line-apps.com/r/myhome/vc/"+cv
          res+="\nLink image : https://obs.line-apps.com/r/myhome/c/"+c
          return res
        else:
          c = home['result']['coverObsInfo']['objectId']
          res="Link image : https://obs.line-apps.com/r/myhome/c/"+c
          return res
    """Post"""

    @loggedIn
    def createPost(self, text, holdingTime=None):
        params = {'homeId': self.profile.mid, 'sourceType': 'TIMELINE'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {'postInfo': {'readPermission': {'type': 'ALL'}}, 'sourceType': 'TIMELINE', 'contents': {'text': text}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()
    @loggedIn
    def createPost2(self, text, holdingTime=None,textMeta=[]):
        params = {'homeId': self.profile.mid, 'sourceType': 'TIMELINE'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {'postInfo': {'readPermission': {'type': 'ALL'}}, 'sourceType': 'TIMELINE', 'contents': {'text': text,'textMeta':textMeta}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()
      
    @loggedIn
    def createComment(self, mid, postId, text):
        if mid is None:
            mid = self.profile.mid
        params = {'homeId': mid, 'sourceType': 'TIMELINE'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/comment/create.json', params)
        data = {'commentText': text, 'activityExternalId': postId, 'actorId': mid}
        data = json.dumps(data)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def deleteComment(self, mid, postId, commentId):
        if mid is None:
            mid = self.profile.mid
        params = {'homeId': mid, 'sourceType': 'TIMELINE'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/comment/delete.json', params)
        data = {'commentId': commentId, 'activityExternalId': postId, 'actorId': mid}
        data = json.dumps(data)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def likePost(self, mid, postId, likeType=1001):
        if mid is None:
            mid = self.profile.mid
        if likeType not in [1001,1002,1003,1004,1005,1006]:
            raise Exception('Invalid parameter likeType')
        params = {'homeId': mid, 'sourceType': 'TIMELINE'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/like/create.json', params)
        data = {'likeType': likeType, 'activityExternalId': postId, 'actorId': mid}
        data = json.dumps(data)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def unlikePost(self, mid, postId):
        if mid is None:
            mid = self.profile.mid
        params = {'homeId': mid, 'sourceType': 'TIMELINE'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/like/create.json', params)
        data = {'likeType':None,'activityExternalId': postId, 'actorId': mid}
        data = json.dumps(data)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()

    """Group Post"""
    @loggedIn
    def createPostPictureStory(self,path):
        oid,hashs=self.uploadObjStory(path,type="image")
        url="https://gws.line.naver.jp/st/api/v7/story/content/create"
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }
        p={"content":{"sourceType":"USER","contentType":"USER","media":[{"oid":oid,"service":"story","sid":"st","hash":hashs,"mediaType":"IMAGE"}]},"shareInfo":{"shareType":"FRIEND"}}    
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
      
    @loggedIn
    def createPostVideoStory(self,path):
        oid,hashs=self.uploadObjStory(path,type="video")
        url="https://gws.line.naver.jp/st/api/v7/story/content/create"
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }        
        p={"content":{"sourceType":"USER","contentType":"USER","media":[{"oid":oid,"service":"story","sid":"st","hash":hashs,"extra":{"playtime":999999999},"mediaType":"VIDEO"}]},"shareInfo":{"shareType":"FRIEND"}}
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
        
    @loggedIn
    def getPostStory(self):
        url="https://gws.line.naver.jp/st/api/v7/story/list"
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }        
        p={"friendInfos":[{"userMid":self.profile.mid,"friendType":"0000xehEMhBN2D7g","tsId":""}],"clickedFriendInfo":{"userMid":self.profile.mid,"friendType":"0000xehEMhBN2D7g","tsId":""}}
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
        
    @loggedIn
    def deletePostStory(self,contentId):
        url="https://gws.line.naver.jp/st/api/v7/story/content/delete"
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }        
        p={"contentId":contentId}
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
        
    @loggedIn
    def deleteAllPostStory(self):
        a=client.getPostStory()
        b=[co["contentId"] for co in a["result"]["friendStories"][0]["contents"]]
        for c in b:
        	self.deletePostStory(c)
        
    @loggedIn
    def getTimelintTab(self, postLimit=20, likeLimit=6, commentLimit=10, requestTime=0):
        url = self.server.LINE_HOST_DOMAIN + '/tl/api/v57/timeline/tab.json'
        data = {
            "feedRequests": {
                "FEED_LIST": {
                    "version": "v57",
                    "queryParams": {
                        "postLimit": postLimit,
                        "likeLimit": likeLimit,
                        "commentLimit": commentLimit,
                        "requestTime": 0,
                        "userAction": "TAP-REFRESH_UEN",
                        "order": "RANKING"
                    },
                    "requestBody": {
                        "discover": {
                            "contents": ["CP", "PI", "PV", "PL", "LL"]
                        }
                    }
                },
                "STORY": {
                    "version": "v7"
                }
            }
        }
        hr = self.server.additionalHeaders(self.server.timelineHeaders, {
            'x-lhm': "POST",
            'Content-type': "application/json",
            'x-lsr': 'ID'
        })
        r = self.server.postContent(url, headers=hr, data=json.dumps(data))
        result = r.json()
        if result['message'] == 'success':
            return result['result']
        else:
            return False
          
    @loggedIn
    def createGroupPostRelayText(self, groupId, title, text,duration):
        url="https://gws.line.naver.jp/mh/api/v57/relay/create.json?homeId={}&sourceType=TIMELINE".format(groupId)
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }
        p={"postInfo":{"readPermission":{"type":"FRIEND","gids":[]}},"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"}},"media":[],"relay":{"title":title,"duration":duration,"notiFlag":False,"joinedRelays":[{"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"}},"textCards":[{"text":text,"textColor":"#FFFFFF","bgColor":"#2FA7EC"}],"media":[]}}]}}}          
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
      
    @loggedIn
    def joinGroupPostRelayText(self, groupId,relayId, text):
        url="https://gws.line.naver.jp/mh/api/v57/joinedrelay/create.json?homeId={}&sourceType=TIMELINE".format(groupId)
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }
        p={"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"}},"textCards":[{"text":text,"textColor":"#FFFFFF","bgColor":"#FB628D"}],"media":[],"relayId":relayId}}
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
      
    @loggedIn
    def joinGroupPostRelayVideo(self, groupId,relayId,path,text=None):
        objid=self.uploadObjHome3(path,type='video')
        url="https://gws.line.naver.jp/mh/api/v57/joinedrelay/create.json?homeId={}&sourceType=TIMELINE".format(groupId)
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }
        p={"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"}},"media":[{"objectId":objid,"type":"VIDEO","width":1080,"height":1080}],"relayId":relayId}}      
        if text != None:
            p["contents"]["text"] = text        
        data = json.dumps(p)
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
      
    @loggedIn
    def joinGroupPostRelayImage(self, groupId,relayId,path,text=None):
        objid=self.uploadObjHome3(path,type='image')
        url="https://gws.line.naver.jp/mh/api/v57/joinedrelay/create.json?homeId={}&sourceType=TIMELINE".format(groupId)
        hr={
        "x-lsr": "ID",
        "x-line-channeltoken": self.tl.channelAccessToken,
        "content-type": "application/json; charset=UTF-8",
        "x-lal": "id_ID",
        "x-line-global-config": "discover.enable=false; follow.enable=true",
        "x-line-bdbtemplateversion": "v1",
        "x-line-mid": self.profile.mid,
        "x-lpv": "1"
        }
        p={"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"}},"media":[{"objectId":objid,"type":"PHOTO","width":1080,"height":1080,"size":199655,"obsFace":"[]"}],"relayId":relayId}}
        if text != None:
            p["contents"]["text"] = text
        data = json.dumps(p)
        #p={"contents":{"text":text,"media":[{"objectId":objid,"type":"PHOTO","width":1080,"height":1080,"size":195454,"obsFace":"[]"}],"relayId":relayId}}      
        data = json.dumps(p)        
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()      
      
    @loggedIn
    def updateGroupPost(self, text, groupId, postId, holdingTime=None, sticker=None):
        url = "https://gws.line.naver.jp/mh/api/v57/post/update.json?homeId={}&sourceType=GROUPHOME".format(groupId)
        b=sticker[0]
        Sid=b['STKID']
        Pid=b['STKPKGID']
        Ver=b['STKVER']
        payload = {"postInfo":{"postId":postId,"readPermission":{"type":"FRIEND","gids":[]},"editableContents":["ALL"]},"contents":{"text":text,"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"},"stickerStyle":{"backgroundColor":"#FCA8E1"}},"stickers":[{"id":Sid,"packageId":Pid,"packageVersion":Ver,"hasAnimation":True,"hasSound":False,"stickerResourceType":"ANIMATION"}],"media":[]}}
        if holdingTime != None:
           payload["postInfo"]["holdingTime"] = holdingTime
        data = json.dumps(payload)
        hr={
          "x-lsr": "ID",
          "x-line-channeltoken": self.tl.channelAccessToken,
          "content-type": "application/json; charset=UTF-8",
          "x-lal": "id_ID",
          "x-line-global-config": "discover.enable=false; follow.enable=true",
          "x-line-bdbtemplateversion": "v1",
          "x-lpv": "1",
          'x-line-mid': self.profile.mid,
        }
        r = self.server.postContent(url, data=data, headers=hr)
        return r.json()
    @loggedIn
    def createGroupPostMention(self, to, text, holdingTime=None,textMeta=[]):
        params = {'homeId': to, 'sourceType': 'GROUPHOME'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {'postInfo': {'readPermission': {'type': 'ALL'}}, 'sourceType': 'GROUPHOME', 'contents': {'text': text,'textMeta':textMeta}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def createGroupPostText(self, to, text,holdingTime=None):
        params = {'homeId': to, 'sourceType': 'GROUPHOME'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {'postInfo': {'readPermission': {'type': 'ALL'}}, 'sourceType': 'GROUPHOME', 'contents': {'text': text}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()
    @loggedIn
    def createGroupPostImage(self, mid, path,text=None,holdingTime=None):
        objid=self.uploadObjHome1(path,type='image')
        params = {'homeId': mid, 'sourceType': 'GROUPHOME'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {"postInfo":{"readPermission":{"type":"FRIEND","gids":[]}},"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"},"mediaStyle":{"displayType":"GRID_1_A"}},"media":[{"objectId":objid,"type":"PHOTO","width":960,"height":1280,"size":len(open(path, 'rb').read()),"obsFace":"[]"}]}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        elif text != None:
            payload["contents"]["text"] = text
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()
        
    @loggedIn
    def createGroupPostMultyImage(self, mid, path=[],text=None,holdingTime=None):
        dataoid=[]
        for img in path:
          oid=self.uploadObjHome1(img,type='image')
          dataoid.append({"objectId":oid,"type":"PHOTO","width":960,"height":1280,"size":len(open(img, 'rb').read()),"obsFace":"[]"})
        params = {'homeId': mid, 'sourceType': 'GROUPHOME'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {"postInfo":{"readPermission":{"type":"FRIEND","gids":[]}},"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"},"mediaStyle":{"displayType":"GRID_1_A"}},"media":dataoid}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        elif text != None:
            payload["contents"]["text"] = text
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()
      
    @loggedIn
    def createGroupPostVideo(self, mid, path,text=None,holdingTime=None):
        objid=self.uploadObjHome1(path,type='video')
        params = {'homeId': mid, 'sourceType': 'GROUPHOME'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/create.json', params)
        payload = {"postInfo":{"readPermission":{"type":"FRIEND","gids":[]}},"contents":{"contentsStyle":{"textStyle":{"textSizeMode":"NORMAL","backgroundColor":"#FFFFFF","textAnimation":"NONE"},"mediaStyle":{"displayType":"GRID_1_A"}},"media":[{"objectId":objid,"type":"VIDEO","width":1080,"height":1920}]}}
        if holdingTime != None:
            payload["postInfo"]["holdingTime"] = holdingTime
        elif text != None:
            payload["contents"]["text"] = text
        data = json.dumps(payload)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()
        
    @loggedIn
    def getGroupPost(self, mid, postLimit=10, commentLimit=1, likeLimit=1):
        params = {'homeId': mid, 'commentLimit': commentLimit, 'likeLimit': likeLimit, 'sourceType': 'TALKROOM'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_API, '/v39/post/list.json', params)
        r = self.server.getContent(url, headers=self.server.timelineHeaders)
        return r.json()
          
    """Group Album"""

    @loggedIn
    def getGroupAlbum(self, mid):
        params = {'homeId': mid, 'type': 'g', 'sourceType': 'TALKROOM'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_MH, '/album/v3/albums', params)
        r = self.server.getContent(url, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def createGroupAlbum(self, mid, name):
        params = {'homeId': mid,'count':'1','auto':'0'}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_MH, '/album/v3/album', params)
        pay = {'type':'image','title': name}
        data = json.dumps(pay)
        r = self.server.postContent(url, data=data, headers=self.server.timelineHeaders)
        return r.json()

    @loggedIn
    def deleteGroupAlbum(self, mid, albumId):
        params = {'homeId': mid}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_MH, '/album/v3/album/%s' % albumId, params)
        r = self.server.deleteContent(url, headers=self.server.timelineHeaders)
        return r.json()
      
    @loggedIn
    def changeGroupAlbumName(self, mid, albumId, name):
        data = json.dumps({'title': name})
        params = {'homeId': mid}
        url = self.server.urlEncode(self.server.LINE_TIMELINE_MH, '/album/v3/album/%s' % albumId, params)
        r = self.server.putContent(url, data=data, headers=self.server.timelineHeaders)
        if r.status_code != 201:
            raise Exception('Change album name failure.')
        return True

    @loggedIn
    def addImageToAlbum(self,homeId,albumId,path):
        oid=self.uploadObjAlbum(homeId,albumId,path)
        url="https://gws.line.naver.jp/ext/album/api/v4/photos/{}?homeId={}&sourceType=UNDEFINED".format(albumId,homeId)
        hr={
          "x-lsr": "ID",
          "x-line-channeltoken": self.tl.channelAccessToken,
          "content-type": "application/json; charset=UTF-8",
          "x-lal": "id_ID",
          "x-line-global-config": "discover.enable=false; follow.enable=true",
          "x-line-bdbtemplateversion": "v1",
          "x-lpv": "1",
          'x-line-mid': self.profile.mid,
        }
        p={"photos":[{"oid":oid}]}
        data = json.dumps(p)
        r = self.server.putContent(url, data=data, headers=hr)
        return True
        
    @loggedIn
    def addImageMultyToAlbum(self,homeId,albumId,path=[]):
        dataoid=[]
        for img in path:          
          oid=self.uploadObjAlbum(homeId,albumId,img)
          dataoid.append({"oid":oid})
        url="https://gws.line.naver.jp/ext/album/api/v4/photos/{}?homeId={}&sourceType=UNDEFINED".format(albumId,homeId)
        hr={
          "x-lsr": "ID",
          "x-line-channeltoken": self.tl.channelAccessToken,
          "content-type": "application/json; charset=UTF-8",
          "x-lal": "id_ID",
          "x-line-global-config": "discover.enable=false; follow.enable=true",
          "x-line-bdbtemplateversion": "v1",
          "x-lpv": "1",
          'x-line-mid': self.profile.mid,
        }
        p={"photos":dataoid}
        data = json.dumps(p)
        r = self.server.putContent(url, data=data, headers=hr)
        return True

    @loggedIn
    def getImageGroupAlbum(self, mid, albumId, objId, returnAs='path', saveAs=''):
        if saveAs == '':
            saveAs = self.genTempFile('path')
        if returnAs not in ['path','bool','bin']:
            raise Exception('Invalid returnAs value')
        hr = self.server.additionalHeaders(self.server.timelineHeaders, {
            'Content-Type': 'image/jpeg',
            'X-Line-Mid': mid,
            'X-Line-Album': albumId
        })
        params = {'ver': '1.0', 'oid': objId}
        url = self.server.urlEncode(self.server.LINE_OBS_DOMAIN, '/album/a/download.nhn', params)
        r = self.server.getContent(url, headers=hr)
        if r.status_code == 200:
            self.saveFile(saveAs, r.raw)
            if returnAs == 'path':
                return saveAs
            elif returnAs == 'bool':
                return True
            elif returnAs == 'bin':
                return r.raw
        else:
            raise Exception('Download image album failure.')